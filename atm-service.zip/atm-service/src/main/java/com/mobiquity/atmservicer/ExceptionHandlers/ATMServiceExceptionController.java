package com.mobiquity.atmservicer.ExceptionHandlers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ATMServiceExceptionController  {

	@ExceptionHandler(ATMServiceException.class)
	public ResponseEntity<?> handleException() {
	 ErrorMapper atmServiceException = new ErrorMapper("Unprocessed request", HttpStatus.INTERNAL_SERVER_ERROR);
	 ResponseEntity<?> entity = new ResponseEntity<>(atmServiceException, HttpStatus.INTERNAL_SERVER_ERROR);
	 return entity;
	}
	
}
