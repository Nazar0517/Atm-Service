package com.mobiquity.atmservicer.agent;

import java.util.Arrays;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class Agent {
	private static final Logger logger = LoggerFactory.getLogger(Agent.class);
	@Value("${updater.atmagent.location}")
	String hostUrl;

	RestTemplate restTemplate;
	HttpHeaders restHeaders;

	@PostConstruct
	public void initialize() {
		logger.debug("Atm agent url: {}", hostUrl);
		restTemplate = new RestTemplate();
		restHeaders = new HttpHeaders();
		restHeaders.setContentType(MediaType.APPLICATION_JSON);
		restHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	}

	public String getAllAtmDetails() {
		logger.debug("Getting all the Atm's Details");
		String response = restTemplate.getForObject(hostUrl, String.class);
		logger.debug("Full details of Atm {}", response);
		return response;
	}
}
