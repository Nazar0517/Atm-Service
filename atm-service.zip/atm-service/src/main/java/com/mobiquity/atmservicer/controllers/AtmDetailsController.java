package com.mobiquity.atmservicer.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mobiquity.atmservicer.ExceptionHandlers.ATMServiceException;
import com.mobiquity.atmservicer.mappers.AddressMapper;
import com.mobiquity.atmservicer.mappers.AtmAddressHolder;
import com.mobiquity.atmservicer.service.AtmDetailsService;

@RestController
@CrossOrigin
public class AtmDetailsController {
	private static final Logger logger = LoggerFactory.getLogger(AtmDetailsController.class);

	@Autowired
	private AtmDetailsService atmDetailsService;

	@GetMapping("/getAllAtmDetails")
	public ResponseEntity<?> getAllAtmDetails() {
		AtmAddressHolder holder = new AtmAddressHolder();
		List<AddressMapper> allAtmDetails = null;
		try {
			allAtmDetails = atmDetailsService.getAllAtmDetails();
			if(allAtmDetails == null || allAtmDetails.size() <=0 ) {
				throw new ATMServiceException("Empty data received", HttpStatus.NO_CONTENT);
			}
			holder.setAtmAddressDetailList(allAtmDetails);
			ResponseEntity<AtmAddressHolder> entity = new ResponseEntity<AtmAddressHolder>(holder, HttpStatus.OK);
			return entity;
		} catch (ATMServiceException e) {
			ResponseEntity<ATMServiceException> entity = new ResponseEntity<ATMServiceException>(e, e.getStatusCode());
			return entity;
		}

	}

	@GetMapping("/getAtmDetailsByCity")
	public ResponseEntity<?> getAtmDetailsByCity(@RequestParam String city) throws ATMServiceException {
		AtmAddressHolder holder = new AtmAddressHolder();
		List<AddressMapper> atmDetailsByCity = null;
		atmDetailsByCity = atmDetailsService.getAtmDetailsByCity(city);
		holder.setAtmAddressDetailList(atmDetailsByCity);
		ResponseEntity<AtmAddressHolder> entity = new ResponseEntity<AtmAddressHolder>(holder, HttpStatus.OK);
		return entity;
	}
}
