package com.mobiquity.atmservicer.mappers;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonAnySetter;

public class AddressMapper {

	private String functionality;
	private String type;
	private String distance;
	private Address address;
	private OpeningHours openingHours;

	public String getFunctionality() {
		return functionality;
	}
	public void setFunctionality(String functionality) {
		this.functionality = functionality;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDistance() {
		return distance;
	}
	public void setDistance(String distance) {
		this.distance = distance;
	}
	
	public OpeningHours getOpeningHours() {
		return openingHours;
	}
	public void setOpeningHours(OpeningHours openingHours) {
		this.openingHours = openingHours;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
//	public Object getOpeningHours() {
//		return openingHours;
//	}
//	public void setOpeningHours(Object openingHours) {
//		this.openingHours = openingHours;
//	}

}
