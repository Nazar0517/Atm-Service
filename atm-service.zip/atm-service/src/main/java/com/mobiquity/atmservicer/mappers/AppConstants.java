package com.mobiquity.atmservicer.mappers;

public class AppConstants {

	public static final String FUNCTIONALITY ="functionality";
	public static final String TYPE ="type";
	public static final String DISTANCE ="distance";
	public static final String ADDRESS ="address";
	public static final String OPENING_HOURS ="openingHours";
	
	public static final String STREET ="street";
	public static final String HOUSE_NUMBER ="housenumber";
	public static final String POSTAL_CODE ="postalcode";
	public static final String CITY ="city";
	public static final String LONGITUDE ="lng";
	public static final String LATITUDE ="lat";
	public static final String GEO_LOCATION ="geoLocation";
	
	public static final String OPERATING_HOURS ="openingHours";
	public static final String DAY_OF_WEEK ="dayOfWeek";
	public static final String HOURS ="hours";
	public static final String HOUR_FROM ="hourFrom";
	public static final String HOUR_TO ="hourTo";
	
}
