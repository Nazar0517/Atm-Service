package com.mobiquity.atmservicer.mappers;

import java.util.List;

public class AtmAddressHolder {

	private List<AddressMapper> atmAddressDetailList;

	public List<AddressMapper> getAtmAddressDetailList() {
		return atmAddressDetailList;
	}

	public void setAtmAddressDetailList(List<AddressMapper> atmAddressDetailList) {
		this.atmAddressDetailList = atmAddressDetailList;
	}
	
	
}
