package com.mobiquity.atmservicer.mappers;

import java.util.List;

public class OpeningHours {

	private List<OpeningHoursMapper> hoursMapper;

	public List<OpeningHoursMapper> getHoursMapper() {
		return hoursMapper;
	}

	public void setHoursMapper(List<OpeningHoursMapper> hoursMapper) {
		this.hoursMapper = hoursMapper;
	}
	
	
	
}
