package com.mobiquity.atmservicer.mappers;

public class OpeningHoursMapper {

	private String dayOfWeek;
	private Hours hour;
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public Hours getHour() {
		return hour;
	}
	public void setHour(Hours hour) {
		this.hour = hour;
	}

}
