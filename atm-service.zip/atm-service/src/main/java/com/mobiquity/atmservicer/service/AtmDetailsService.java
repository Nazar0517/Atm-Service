package com.mobiquity.atmservicer.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.mobiquity.atmservicer.ExceptionHandlers.ATMServiceException;
import com.mobiquity.atmservicer.agent.Agent;
import com.mobiquity.atmservicer.mappers.Address;
import com.mobiquity.atmservicer.mappers.AddressMapper;
import com.mobiquity.atmservicer.mappers.AppConstants;
import com.mobiquity.atmservicer.mappers.GeoLocation;
import com.mobiquity.atmservicer.mappers.Hours;
import com.mobiquity.atmservicer.mappers.OpeningHours;
import com.mobiquity.atmservicer.mappers.OpeningHoursMapper;

@Service
public class AtmDetailsService implements AtmDetailsServicer{
	private static final Logger logger = LoggerFactory.getLogger(AtmDetailsService.class);
	private static List<AddressMapper> allAtmDetailsList = null;
	private static Map<String, List<AddressMapper>> addressCache = new HashMap<String, List<AddressMapper>>();

	@Autowired
	private Agent agent;

	@PostConstruct
	private void postConstructAtmDetails() throws ATMServiceException {
		String allAtmDetails = agent.getAllAtmDetails();
		allAtmDetailsList =parseAtmDetailsJson(allAtmDetails);
		for (AddressMapper addressMapper : allAtmDetailsList) {
			Address address = addressMapper.getAddress();
			String city = address.getCity();
			if(!addressCache.containsKey(city)) {
				ArrayList<AddressMapper> list = new ArrayList<AddressMapper>();
				list.add(addressMapper);
				addressCache.put(city, list);
			} else {
				List<AddressMapper> list = addressCache.get(city);
				list.add(addressMapper);
			}
		}
	}

	@Override
	public List<AddressMapper> getAtmDetailsByCity(String city) throws ATMServiceException  {
		List<AddressMapper> list = addressCache.get(city);
		if(list != null && list.size() > 0) {
			return list;
		} else {
			throw new ATMServiceException("No data found with requested city");
		}
	}
	
	@Override
	public List<AddressMapper> getAllAtmDetails() throws  ATMServiceException  {
		if(allAtmDetailsList == null && allAtmDetailsList.size() == 0) {
			String allAtmDetails = agent.getAllAtmDetails();
			allAtmDetailsList =parseAtmDetailsJson(allAtmDetails);
		} 
		return allAtmDetailsList;
	}

	private List<AddressMapper> parseAtmDetailsJson(String jsonString) throws ATMServiceException   {
		if(allAtmDetailsList != null && allAtmDetailsList.size() > 0) {
			return allAtmDetailsList;
		}

		List<AddressMapper> atmDetailsList = new ArrayList<AddressMapper>();

		try {
			String formatedJson = jsonString.substring(jsonString.indexOf('['), jsonString.length());
			if(formatedJson == null || formatedJson.length() == 0) {
				throw new ATMServiceException("Invalid data received from agent", HttpStatus.UNPROCESSABLE_ENTITY);
			}

			logger.debug("Formatted Json {}", formatedJson);
			JSONArray resultArray = new JSONArray(formatedJson);
			int length = resultArray.length();

			for(int i =0; i<length; i++ ) {
				JSONObject jsonObject = resultArray.getJSONObject(i);
				Iterator<String> keys = jsonObject.keys();
				AddressMapper details = new AddressMapper();

				//If Contract is fixed
				while(keys.hasNext()) {
					String key = keys.next();
					switch(key) {
					case AppConstants.FUNCTIONALITY:
						details.setFunctionality(jsonObject.optString(key));
						break;
					case AppConstants.TYPE:
						details.setType(jsonObject.optString(key));
						break;
					case AppConstants.DISTANCE:
						details.setDistance(jsonObject.optString(key));
						break;
					case AppConstants.ADDRESS:						
						JSONObject addressJson = (JSONObject)jsonObject.opt(key);
						Iterator<String> addressKeys = addressJson.keys();
						Address address = new Address();
						while(addressKeys.hasNext()) {
							String addressKey = addressKeys.next();
							switch(addressKey) {
							case AppConstants.STREET:
								address.setStreet(addressJson.optString(addressKey));
								break;
							case AppConstants.HOUSE_NUMBER:
								address.setHousenumber(addressJson.optString(addressKey));
								break;
							case AppConstants.POSTAL_CODE:
								address.setPostalcode(addressJson.optString(addressKey));
								break;
							case AppConstants.CITY:
								address.setCity(addressJson.optString(addressKey));
								break;
							case AppConstants.GEO_LOCATION:
								JSONObject geoJson = (JSONObject)addressJson.opt(addressKey);
								Iterator<String> geoJsonKeys = geoJson.keys();
								GeoLocation location = new GeoLocation();
								while(geoJsonKeys.hasNext()) {

									String geoKey = geoJsonKeys.next();
									switch(geoKey) {
									case AppConstants.LONGITUDE:
										location.setLongitude(geoJson.optString(geoKey));
										break;
									case AppConstants.LATITUDE:
										location.setLatitude(geoJson.optString(geoKey));
										break;

									}
									address.setGeoLocation(location);	
								}
							}
						}

						details.setAddress(address);					
						break;
					case AppConstants.OPENING_HOURS:
						JSONArray openingHoursJson = (JSONArray)jsonObject.opt(key);
						OpeningHours oh = new OpeningHours();
						List<OpeningHoursMapper> list = new ArrayList<OpeningHoursMapper>();
						OpeningHours openingHours = new OpeningHours();
						int openingHoursLength = openingHoursJson.length();
						for(int j =0; j<openingHoursLength; j++ ) {
							JSONObject openingHour = (JSONObject)openingHoursJson.opt(j);
							if(openingHour != null && openingHour.length() > 0) {
								Iterator itr = openingHour.keys();
								OpeningHoursMapper mapper = new OpeningHoursMapper();
								while(itr.hasNext()) {

									String openingHourKey = (String)itr.next();
									switch (openingHourKey) {
									case AppConstants.DAY_OF_WEEK:
										mapper.setDayOfWeek(openingHour.optString(openingHourKey));
										break;
									case AppConstants.HOURS:
										JSONArray hour = (JSONArray)openingHour.opt(openingHourKey);
										int hourLength = hour.length();
										if(hour != null && hourLength > 0) {

											for(int k=0; k< hourLength; k++ ) {
												JSONObject hourObject = (JSONObject)hour.get(k);
												Iterator hourItr = hourObject.keys();
												Hours hours = new Hours();
												while(hourItr.hasNext()) {
													String hourKey = (String)hourItr.next();
													switch (hourKey) {
													case AppConstants.HOUR_FROM:
														hours.setHourFrom(hourObject.optString(hourKey));
														break;
													case AppConstants.HOUR_TO:
														hours.setHourTo(hourObject.optString(hourKey));
														break;
													}
												}
												mapper.setHour(hours);
											}
										}
										break;
									}

								}
								list.add(mapper);
							} else {
								break;
							}
						}
						oh.setHoursMapper(list);
						details.setOpeningHours(oh);
						break;
					}
				}
				atmDetailsList.add(details);
			}
		} catch (Throwable e) {
			throw new ATMServiceException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return atmDetailsList;
	}
}
