package com.mobiquity.atmservicer.service;

import java.util.List;

import com.mobiquity.atmservicer.mappers.AddressMapper;

public interface AtmDetailsServicer {

	public List<AddressMapper> getAllAtmDetails() throws Throwable;
	public List<AddressMapper> getAtmDetailsByCity(String city)throws Throwable;
	
}
