package com.mobiquity.atmservicer.controllers;

import static org.mockito.ArgumentMatchers.any;

import org.junit.Assert;
import org.junit.Test;
import org.junit.platform.commons.util.StringUtils;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobiquity.atmservicer.service.AtmDetailsService;

@WebMvcTest(AtmDetailsController.class)
@RunWith(SpringRunner.class)
public class AtmDetailsControllerTest extends ControllerTestBase{

	@MockBean
	AtmDetailsService atmDetailsServicer;
	
	ObjectMapper mapper = new ObjectMapper();
	
	
	@Test
	public void testGetAllAtmDetailsNegitiveCase() throws Throwable {
		Mockito.when(atmDetailsServicer.getAllAtmDetails()).thenReturn(null);
		MvcResult return1 = mvc.perform(MockMvcRequestBuilders.get("/getAllAtmDetails")).andExpect(MockMvcResultMatchers.status().isNoContent()).andReturn();
		String contentAsString = return1.getResponse().getContentAsString();
		
		Assert.assertFalse("Empty Response",StringUtils.isBlank(contentAsString));
		
	}
	
	@Test
	public void testGetAllAtmDetails() throws Throwable {
		MvcResult return1 = mvc.perform(MockMvcRequestBuilders.get("/getAllAtmDetails")).andExpect(MockMvcResultMatchers.status().isNoContent()).andReturn();
		MockHttpServletResponse contentAsString = return1.getResponse();
	}

	@Test
	public void testGetAtmDetailsByCity() throws Throwable {
		Mockito.when(atmDetailsServicer.getAtmDetailsByCity(any())).thenReturn(null);
		MvcResult return1 = mvc.perform(MockMvcRequestBuilders.get("/getAtmDetailsByCity")).andExpect(MockMvcResultMatchers.status().isBadRequest()).andReturn();
		String contentAsString = return1.getResponse().getContentAsString();
		Assert.assertTrue("Empty Response",StringUtils.isBlank(contentAsString));
	}
	
	@Test
	public void testGetAtmDetailsByCityName() throws Throwable {
		 ResultActions return1 = mvc.perform(MockMvcRequestBuilders.get("/getAtmDetailsByCity").param("city", "Zaandam"));
		String contentAsString = return1.andReturn().getResponse().getContentAsString();
		Assert.assertFalse("Response",StringUtils.isBlank(contentAsString));
	}
}
