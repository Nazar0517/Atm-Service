package com.mobiquity.atmservicer.service;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.mobiquity.atmservicer.ExceptionHandlers.ATMServiceException;
import com.mobiquity.atmservicer.mappers.AddressMapper;

@RunWith(SpringRunner.class)
public class AtmDetailsServiceTest {

	@MockBean
	AtmDetailsService atmDetailsService;
	
	@Test
	public void testGetAtmDetailsByCity() throws ATMServiceException{
//		Mockito.when(atmDetailsService.getAtmDetailsByCity("Zaandam")).thenCallRealMethod().thenThrow(ATMServiceException.class);
		List<AddressMapper> atmDetailsByCity = atmDetailsService.getAtmDetailsByCity("Zaandam");
		Assert.assertTrue(atmDetailsByCity.size() == 0);
		
	}
}
